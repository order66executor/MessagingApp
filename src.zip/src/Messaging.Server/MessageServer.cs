using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;

using Messaging.Shared;
using Messaging.Shared.Protocols;

namespace Messaging.Server;

public class MessageServer {

    public int Port { get; set; }

    private readonly IMessageProtocol protocol;

    private readonly TcpListener listener;

    private readonly ConcurrentDictionary<StringIdentifier, MessageConnectionHandler> users;

    private readonly List<Task> tasks;

    public MessageServer(int port, IMessageProtocol protocol) {
        Port = port;
        this.protocol = protocol;
        listener = new(IPAddress.Any, Port);
        users = [ ];
        tasks = [ ];
    }

    public async Task RunAsync(CancellationToken ct) {
        listener.Start();

        while (!ct.IsCancellationRequested) {
            TcpClient client;
            try {
                client = await listener.AcceptTcpClientAsync(ct);
            }
            catch (OperationCanceledException) {
                Console.WriteLine("TCP listening cancelled");
                break;
            }

            tasks.Add(HandleConnectionAsync(client, ct));
            
        }

        listener.Stop();
        listener.Dispose();

        foreach (Task task in tasks) await task;

    }

    public async Task HandleConnectionAsync(TcpClient client, CancellationToken ct) {
        using CancellationTokenSource cts = new();
        using CancellationTokenSource linked = CancellationTokenSource.CreateLinkedTokenSource(ct, cts.Token);

        MessageConnection conn = new(client, linked.Token);

        Task connTask;

        connTask = conn.StartAsync();

        using CancellationTokenSource introCts = CancellationTokenSource.CreateLinkedTokenSource(linked.Token);
        introCts.CancelAfter(5000);

        bool introduced;

        try {
            await conn.Buffer.Reader.WaitToReadAsync(introCts.Token);
            introduced = true;
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested) {
            introduced = false;
        }

        MessageConnectionHandler handler;

        if (introduced) {
            StringIdentifier id = protocol.ReceiveIntroduction(await conn.Buffer.Reader.ReadAsync(linked.Token));

            Console.WriteLine($"Introduction received, ID: {id.Value}");

            handler = new(protocol, conn, linked.Token, -1, -1);
            users.TryAdd(id, handler);

            await handler.WriteToOutBufferAsync(protocol.CreateAck(0, new StringIdentifier("SYSTEM"), id, 1));
        }
        else {
            Console.WriteLine("Introduction not received or operation cancelled");
            cts.Cancel();
            await connTask;
            return;
        }
        
        await handler.StartProcessingAsync();
        cts.Cancel();
        await connTask;
    }
}